﻿namespace mission8Assignment.Models
{
    public class QuadrantsViewModel
    {
        public List<Task> QuadrantI { get; set; } = new List<Task>();
        public List<Task> QuadrantII { get; set; } = new List<Task>();
        public List<Task> QuadrantIII { get; set; } = new List<Task>();
        public List<Task> QuadrantIV { get; set; } = new List<Task>();
    }
}
