﻿namespace mission8Assignment.Models
{
    public interface ITaskRepository
    {
        List<Task> Tasks { get; }
    }

}
